#import <UIKit/UIKit.h>
#import <MuDocRef.h>

@interface MuPrintPageRenderer : UIPrintPageRenderer

-(id) initWithDocRef:(MuDocRef *) docRef;

@end
