#import <Foundation/Foundation.h>

@protocol MuUpdater <NSObject>
- (void)update;
@end
