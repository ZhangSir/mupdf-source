package org.apache.pdfbox.pdmodel.graphics.blend;

public class SoftMaskPaint {

}
