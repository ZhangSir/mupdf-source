package com.artifex.mupdfdemo;

public enum WidgetType {
	NONE,
	TEXT,
	LISTBOX,
	COMBOBOX,
	SIGNATURE
}
