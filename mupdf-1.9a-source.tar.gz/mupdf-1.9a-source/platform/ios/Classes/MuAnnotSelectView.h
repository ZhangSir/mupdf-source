#import <UIKit/UIKit.h>
#import "MuAnnotation.h"

@interface MuAnnotSelectView : UIView
- (id) initWithAnnot:(MuAnnotation *)_annot pageSize:(CGSize)_pageSize;
@end
