#import <UIKit/UIKit.h>

@class MuDocumentController;

@interface MuOutlineController : UITableViewController
- (id) initWithTarget: (id)aTarget titles: (NSMutableArray*)aTitles pages: (NSMutableArray*)aPages;
@end
