package com.artifex.mupdf.fitz;

public class TryLaterException extends Exception
{
	TryLaterException(String message) {
		super(message);
	}
}
